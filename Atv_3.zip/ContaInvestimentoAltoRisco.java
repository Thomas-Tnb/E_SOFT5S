package org.example;

public class ContaInvestimentoAltoRisco extends ContaInvestimento {
    private static final double TAXA_SAQUE = 0.05; // 5% de taxa
    private static final double SALDO_MINIMO_SAQUE = 10000.00; // Saldo mínimo exigido para saque

    public ContaInvestimentoAltoRisco(int numeroConta, String titular, float saldo) {
        super(numeroConta, titular, saldo);
    }

    @Override
    public void sacar(double valor) {
        double valorComTaxa = valor + (valor * TAXA_SAQUE); // Aplica a taxa de 5%

        // Verifica se o saldo após o saque permanecerá acima do mínimo exigido
        if (getSaldo() - valorComTaxa >= SALDO_MINIMO_SAQUE) {
            setSaldo((float) (getSaldo() - valorComTaxa));
            System.out.println("Saque realizado com sucesso.");
            System.out.println("Taxa aplicada: R$ " + (valor * TAXA_SAQUE));
            System.out.println("Saldo atual: R$ " + getSaldo());
        } else {
            System.out.println("Saque não permitido. O saldo mínimo de R$ 10.000,00 deve ser mantido.");
        }
    }
}
