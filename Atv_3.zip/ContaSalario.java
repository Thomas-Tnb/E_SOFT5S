package org.example;

public class ContaSalario extends ContaCorrente {
    private int saquesRealizados;
    private static final double TAXA_SAQUE = 5.00; // Taxa aplicada após o primeiro saque gratuito

    public ContaSalario(int numeroConta, String titular, float saldo, double limiteCheque) {
        super(numeroConta, titular, saldo, limiteCheque);
        this.saquesRealizados = 0;
    }

    @Override
    public void sacar(double valor) {
        double valorFinal = valor;

        // Se já realizou um saque no mês, aplica a taxa
        if (saquesRealizados > 0) {
            valorFinal += TAXA_SAQUE;
        }

        // Verifica se há saldo suficiente considerando a taxa
        if (valorFinal <= getSaldo()) {
            setSaldo((float) (getSaldo() - valorFinal));
            saquesRealizados++;
            System.out.println("Saque realizado com sucesso. Saldo atual: R$ " + getSaldo());
        } else {
            System.out.println("Saldo insuficiente para realizar o saque.");
        }
    }

    // Método para resetar a contagem de saques todo mês
    public void resetarSaquesMensais() {
        saquesRealizados = 0;
    }
}

