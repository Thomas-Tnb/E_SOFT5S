package org.example;

public class ContaPoupanca extends ContaBancaria{
    public ContaPoupanca(int numeroConta, String titular, float saldo) {
        super(numeroConta, titular, saldo);
    }

    @Override
    public void sacar(double valor) {
        if(valor <= this.getSaldo()){
            this.setSaldo((float) (this.getSaldo() - valor));
            System.out.println("Saldo atual : " + this.getSaldo());
        }else{
            System.out.println("Saldo insuficiente...");
        }
    }
}
