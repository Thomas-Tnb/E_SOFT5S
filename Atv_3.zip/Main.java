package org.example;

public class Main {
    public static void main(String[] args) {
        // Testando Conta Corrente
        System.out.println("### Teste Conta Corrente ###");
        ContaCorrente cc = new ContaCorrente(1001, "João Silva", 5000, 1000);
        cc.exibirInformacoes();
        cc.sacar(3000); // Saque dentro do saldo
        cc.sacar(3000); // Saque utilizando cheque especial

        System.out.println("\n### Teste Conta Poupança ###");
        ContaPoupanca cp = new ContaPoupanca(1002, "Maria Santos", 2000);
        cp.exibirInformacoes();
        cp.sacar(1500); // Saque permitido
        cp.sacar(1000); // Saque negado (saldo insuficiente)

        System.out.println("\n### Teste Conta Investimento ###");
        ContaInvestimento ci = new ContaInvestimento(1003, "Carlos Almeida", 10000);
        ci.exibirInformacoes();
        ci.sacar(2000); // Saque com taxa de 2%

        System.out.println("\n### Teste Conta Salário ###");
        ContaSalario cs = new ContaSalario(1004, "Ana Pereira", 3000, 500);
        cs.exibirInformacoes();
        cs.sacar(1000); // Primeiro saque gratuito
        cs.sacar(500);  // Segundo saque com taxa de R$ 5,00
        cs.resetarSaquesMensais(); // Reseta os saques no mês
        cs.sacar(500);  // Primeiro saque gratuito novamente

        System.out.println("\n### Teste Conta Investimento Alto Risco ###");
        ContaInvestimentoAltoRisco cial = new ContaInvestimentoAltoRisco(1005, "Bruno Castro", 15000);
        cial.exibirInformacoes();
        cial.sacar(3000); // Saque com taxa de 5% permitido
        cial.sacar(5000); // Saque negado (saldo ficaria abaixo de R$ 10.000)

        System.out.println("\n### Testes Finalizados ###");
    }
}
