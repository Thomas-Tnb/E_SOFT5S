package org.example;

public class ContaInvestimento extends ContaBancaria {

    private static final double TAXA_SAQUE = 0.02; // 2% de taxa

    public ContaInvestimento(int numeroConta, String titular, float saldo) {
        super(numeroConta, titular, saldo);
    }

    @Override
    public void sacar(double valor) {
        double valorComTaxa = valor + (valor * TAXA_SAQUE); // Aplica a taxa de 2%

        if (valorComTaxa <= getSaldo()) {
            setSaldo((float) (getSaldo() - valorComTaxa));
            System.out.println("Saque realizado com sucesso. Taxa aplicada: R$ " + (valor * TAXA_SAQUE));
            System.out.println("Saldo atual: R$ " + getSaldo());
        } else {
            System.out.println("Saldo insuficiente para realizar o saque com a taxa aplicada.");
        }
    }
}
