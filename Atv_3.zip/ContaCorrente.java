package org.example;

public class ContaCorrente extends ContaBancaria{
    private double limiteCheque;

    public ContaCorrente(int numeroConta, String titular, float saldo, double limiteCheque) {
        super(numeroConta, titular, saldo);
        this.limiteCheque = limiteCheque;
    }

    public double getLimiteCheque() {
        return limiteCheque;
    }

    public void setLimiteCheque(double limiteCheque) {
        this.limiteCheque = limiteCheque;
    }

    @Override
    public void sacar(double valor){
        if(valor <= this.getSaldo()){
            this.setSaldo((float) (this.getSaldo() - valor));
            System.out.println("Saldo atual : " + this.getSaldo());
        }else if(valor <= (limiteCheque)){
            this.setSaldo(0);
            double diff = valor - this.getSaldo();
            this.setLimiteCheque(this.getLimiteCheque() - diff);
            System.out.println("Limite restante:" + this.getLimiteCheque());
        }
    }
}
