package org.example;

public class CaminhaoRefrigerado extends Caminhao{
    private int tempMinima;

    public CaminhaoRefrigerado(String marca, String modelo, int ano, int capacidadePassageiros, String combustivel, int tanque, int consumo, double capacidadeCarga, int tempMinima) {
        super(marca, modelo, ano, capacidadePassageiros, combustivel, tanque, consumo, capacidadeCarga);
        this.tempMinima = tempMinima;
    }

    public int getTempMinima() {
        return tempMinima;
    }

    public void setTempMinima(int tempMinima) {
        this.tempMinima = tempMinima;
    }

    @Override
    public double calcularAutonomia() {
        return super.calcularAutonomia() * 0.9;
    }
}
