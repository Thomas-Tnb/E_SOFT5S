package org.example;

public class CarroEletrico extends Carro{
    private double bateriaKwh;

    public CarroEletrico(String marca, String modelo, int ano, int capacidadePassageiros, String combustivel, String tipoCarro, int tanque, int consumo, double bateriaKwh) {
        super(marca, modelo, ano, capacidadePassageiros, combustivel, tipoCarro, tanque, consumo);
        this.bateriaKwh = bateriaKwh;
    }

    public double getBateriaKwh() {
        return bateriaKwh;
    }

    public void setBateriaKwh(double bateriaKwh) {
        this.bateriaKwh = bateriaKwh;
    }

    @Override
    public double calcularAutonomia(){
        return this.getBateriaKwh() * 5;
    }
}
