package org.example;

public class Caminhao extends Veiculo{
    private int tanque;
    private double consumo;
    private double capacidadeCarga;
    private double pConsumo;

    public Caminhao(String marca, String modelo, int ano, int capacidadePassageiros, String combustivel, int tanque, int consumo, double capacidadeCarga) {
        super(marca, modelo, ano, capacidadePassageiros, combustivel);
        this.tanque = tanque;
        this.pConsumo = (capacidadeCarga >= 25) ? 0.25 : (capacidadeCarga / 100.0);
        this.consumo = (double) this.getConsumo() - (this.getConsumo() * this.getpConsumo());
        this.capacidadeCarga = capacidadeCarga;
    }

    public int getTanque() {
        return tanque;
    }

    public void setTanque(int tanque) {
        this.tanque = tanque;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public void setCapacidadeCarga(double capacidadeCarga) {
        this.capacidadeCarga = capacidadeCarga;
    }

    public double getpConsumo() {
        return pConsumo;
    }

    public void setpConsumo(double pConsumo) {
        this.pConsumo = pConsumo;
    }

    @Override
    public double calcularAutonomia() {
        return (double) this.getTanque() * this.getConsumo();
    }
}
