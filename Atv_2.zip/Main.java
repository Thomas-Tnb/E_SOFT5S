package org.example;

public class Main {
    public static void main(String[] args) {
        // Criando e testando um Carro
        Carro carro = new Carro("Toyota", "Corolla", 2022, 5, "Gasolina", "Sedan", 50, 12);
        carro.exibirDetalhes();
        System.out.println("Autonomia: " + carro.calcularAutonomia() + " km\n");

        // Criando e testando um Caminhão
        Caminhao caminhao = new Caminhao("Volvo", "FH", 2020, 2, "Diesel", 300, 5, 20);
        caminhao.exibirDetalhes();
        System.out.println("Autonomia: " + caminhao.calcularAutonomia() + " km\n");

        // Criando e testando um Ônibus
        try {
            Onibus onibus = new Onibus("Mercedes-Benz", "O500", 2021, 40, "Diesel", 6, 200, 4);
            onibus.exibirDetalhes();
            System.out.println("Autonomia: " + onibus.calcularAutonomia() + " km\n");
        } catch (Exception e) {
            System.out.println("Erro ao criar ônibus: " + e.getMessage());
        }

        // Criando e testando um Carro Elétrico
        CarroEletrico carroEletrico = new CarroEletrico("Tesla", "Model S", 2023, 5, "Elétrico", "Sedan", 0, 0, 100);
        carroEletrico.exibirDetalhes();
        System.out.println("Autonomia: " + carroEletrico.calcularAutonomia() + " km\n");

        // Criando e testando um Caminhão Refrigerado
        CaminhaoRefrigerado caminhaoRefrigerado = new CaminhaoRefrigerado("Scania", "R450", 2019, 2, "Diesel", 250, 4, 30, -10);
        caminhaoRefrigerado.exibirDetalhes();
        System.out.println("Autonomia: " + caminhaoRefrigerado.calcularAutonomia() + " km\n");
    }
}
