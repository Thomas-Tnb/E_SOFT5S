package org.example;

public class Onibus extends Veiculo{
    private int quantEixos;
    private int tanque;
    private int consumo;

    public Onibus(String marca, String modelo, int ano, int capacidadePassageiros, String combustivel, int quantEixos, int tanque, int consumo) throws Exception {
        super(marca, modelo, ano, capacidadePassageiros, combustivel);
        if(quantEixos > 8 || quantEixos < 6){
            throw new Exception("Quantidade de eixos inválida");
        }
        else{
            this.quantEixos = quantEixos;
        }
        this.tanque = tanque;
        this.consumo = consumo;
    }

    public int getQuantEixos() {
        return quantEixos;
    }

    public void setQuantEixos(int quantEixos) {
        this.quantEixos = quantEixos;
    }

    public int getTanque() {
        return tanque;
    }

    public void setTanque(int tanque) {
        this.tanque = tanque;
    }

    public int getConsumo() {
        return consumo;
    }

    public void setConsumo(int consumo) {
        this.consumo = consumo;
    }


    @Override
    public double calcularAutonomia() {
        return (double) this.getTanque() * this.getConsumo();
    }
}
